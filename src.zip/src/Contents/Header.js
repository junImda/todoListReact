import React, { Component } from 'react'
import Button from 'react-bootstrap/Button';
import { Container, Modal } from 'react-bootstrap';

class Header extends Component {
    render() {
        return (
            <div class="my-5">
                <h1>Todo List</h1>
            </div>
        )
    }
}

export default Header
